# 细胞模型网站部署说明

这个文件夹就是可以上传的网站目录。入口文件是 `index.html`，Three.js 依赖已经放在 `vendor/` 目录里，不依赖外部 CDN。

## 最快发布方式：Netlify

1. 打开 https://app.netlify.com/drop
2. 登录 Netlify
3. 把整个 `cell-model-site` 文件夹拖进去
4. 等待上传完成，Netlify 会生成一个 `https://xxxxx.netlify.app` 网址

## 其他方式

- Vercel：导入这个文件夹或 Git 仓库即可。
- GitHub Pages：把本文件夹内容推到仓库，开启 Pages。
- 阿里云/腾讯云静态托管：上传本文件夹内容到对象存储或静态网站服务。

发布时请上传整个文件夹，不要只上传 `index.html`，否则 3D 依赖文件无法加载。
